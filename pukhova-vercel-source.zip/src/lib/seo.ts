import type {Metadata} from 'next';
import {siteUrl} from './site-url';
export function meta(title:string,description:string,path:string):Metadata{
 const origin=siteUrl();
 const canonical=new URL(path,origin).toString();
 return {title:`${title} — Алексея Пуховой`,description,alternates:{canonical},openGraph:{title,description,url:canonical,siteName:'Мебельное производство Алексея Пуховой',locale:'ru_RU',type:'website',images:[{url:new URL('/images/hero-dark.png',origin).toString(),width:1672,height:941,alt:'Концептуальный интерьер с мебелью'}]}};
}
const descriptions:Record<string,string>={home:'Мебель по индивидуальным размерам: кухни, шкафы и решения для хранения.',projects:'Направления мебели и демонстрационные проекты.',production:'Подход к проектированию и изготовлению мебели.',journal:'Советы о мебели, материалах и планировании пространства.',contacts:'Обсудите мебель по индивидуальным размерам.'};
export function description(key:string){return descriptions[key]||''}
