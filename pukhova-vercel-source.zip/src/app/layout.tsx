import type {Metadata} from 'next';
import '@fontsource-variable/golos-text';
import '@fontsource-variable/unbounded';
import './globals.css';
import {Header} from '@/components/Header';
import {Footer} from '@/components/Footer';
import {preview} from '@/lib/content';
import {siteUrl} from '@/lib/site-url';
export const metadata:Metadata={metadataBase:siteUrl(),title:'Мебельное производство Алексея Пуховой',description:'Мебель по индивидуальным размерам для дома и бизнеса.',robots:{index:false,follow:false}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ru"><body>{preview()&&<div className="preview-banner">Пример сайта · интерьеры и проекты демонстрационные</div>}<Header/><main id="main">{children}</main><Footer/></body></html>}

