import type {MetadataRoute} from 'next';
import {siteUrl} from '@/lib/site-url';

export default function sitemap():MetadataRoute.Sitemap {
 const origin=siteUrl();
 return ['/','/projects','/production','/journal','/contacts'].map(path=>({
  url:new URL(path,origin).toString(),
  changeFrequency:'monthly',
  priority:path==='/'?1:0.7,
 }));
}
