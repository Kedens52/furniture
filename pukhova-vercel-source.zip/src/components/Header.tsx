'use client';
import Link from 'next/link';
import Image from 'next/image';
import {useEffect,useRef,useState} from 'react';
const links=[['/projects','Мебель и проекты'],['/production','Производство'],['/journal','Журнал'],['/contacts','Контакты']];
export function Header(){
 const [open,setOpen]=useState(false),[scrolled,setScrolled]=useState(false);
 const menu=useRef<HTMLElement>(null),toggle=useRef<HTMLButtonElement>(null);
 useEffect(()=>{const onScroll=()=>setScrolled(window.scrollY>35);onScroll();window.addEventListener('scroll',onScroll,{passive:true});return()=>window.removeEventListener('scroll',onScroll)},[]);
 useEffect(()=>{if(!open)return; const previous=document.activeElement as HTMLElement;const node=menu.current;const button=toggle.current;node?.querySelector<HTMLElement>('a')?.focus();const onKey=(e:KeyboardEvent)=>{if(e.key==='Escape')setOpen(false);if(e.key==='Tab'&&node){const items=[...node.querySelectorAll<HTMLElement>('a,button')];const first=items[0],last=items.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus()}}};document.addEventListener('keydown',onKey);return()=>{document.removeEventListener('keydown',onKey);(previous===button?button:previous)?.focus()}},[open]);
 return <header className={`site-header ${scrolled||open?'solid':''}`}><div className="header-inner wrap"><Link href="/" className="brand" aria-label="Алексея Пуховой — на главную" onClick={()=>setOpen(false)}><span className="brand-logo"><Image src="/images/pukhova-logo.png" alt="Алексея Пуховой" width={1346} height={1168} className="brand-logo-image" priority/></span></Link><nav className="desktop-nav" aria-label="Основная навигация">{links.map(([href,label])=><Link key={href} href={href}>{label}</Link>)}</nav><Link className="header-cta" href="/contacts#request">Обсудить проект <span aria-hidden>↗</span></Link><button ref={toggle} className="menu-toggle" aria-label={open?'Закрыть меню':'Открыть меню'} aria-expanded={open} onClick={()=>setOpen(!open)}>{open?'Закрыть':'Меню'}<span aria-hidden>{open?'×':'☰'}</span></button></div>{open&&<nav ref={menu} className="mobile-menu" aria-label="Мобильная навигация">{links.map(([href,label])=><Link onClick={()=>setOpen(false)} key={href} href={href}>{label}<span aria-hidden>↗</span></Link>)}<Link onClick={()=>setOpen(false)} href="/contacts#request">Обсудить проект <span aria-hidden>↗</span></Link></nav>}</header>
}


